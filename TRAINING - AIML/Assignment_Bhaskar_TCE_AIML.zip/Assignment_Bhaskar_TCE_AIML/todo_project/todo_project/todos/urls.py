from django.urls import path
from . import views

urlpatterns = [
    path('api/todos/', views.todo_api_view, name='todo-api'),
    path('', views.todo_list_view, name='todo-list'),  # Main page displaying all to-dos
    path('todo/new/', views.todo_form_view, name='todo-create'),  # Form view for creating a new to-do
    path('todo/<int:id>/', views.todo_form_view, name='todo-update'),  # Form view for updating an existing to-do
]
