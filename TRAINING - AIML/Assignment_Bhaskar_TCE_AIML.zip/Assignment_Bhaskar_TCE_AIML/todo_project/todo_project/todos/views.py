from django.shortcuts import render, redirect, get_object_or_404
from .models import Todo
from .serializers import TodoSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view

# REST API view for handling GET and POST requests
@api_view(['GET', 'POST'])
def todo_api_view(request):
    if request.method == 'GET':
        todos = Todo.objects.all()
        serializer = TodoSerializer(todos, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = TodoSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

# View to display the list of to-dos
def todo_list_view(request):
    todos = Todo.objects.all()
    return render(request, 'todos/todo_list.html', {'todos': todos})

# View to handle creating/updating to-dos via a form
def todo_form_view(request, id=None):
    if id:
        todo = get_object_or_404(Todo, id=id)
        if request.method == 'POST':
            todo.title = request.POST.get('title')
            todo.description = request.POST.get('description')
            todo.completed = request.POST.get('completed') == 'on'
            todo.save()
            return redirect('todo-list')
    else:
        todo = None
        if request.method == 'POST':
            title = request.POST.get('title')
            description = request.POST.get('description')
            completed = request.POST.get('completed') == 'on'
            Todo.objects.create(title=title, description=description, completed=completed)
            return redirect('todo-list')

    return render(request, 'todos/todo_form.html', {'todo': todo})
